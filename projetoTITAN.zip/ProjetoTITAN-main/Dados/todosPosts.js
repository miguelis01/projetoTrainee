const listaDePosts = [{
    id: 1,
    titulo: "asdasfasf",
    img: "http://localhost:8080/img1.png",
    texto: " asdasifhauhfgus ",
    data: "20/08",
    categoria: "Estilo de Vida"
},
{
    id: 2,
    titulo: "sad",
    img: "http://localhost:8080/img2.png",
    texto: " asdasifhauhfgdsaffsafasus ",
    data: " safsaassssssssssssssssssssssssssssssssssssssfsg sa",
    categoria: "Tecnologia"
},
{
    id: 3,
    titulo: "sad",
    img: "http://localhost:8080/img2.png",
    texto: " asdasifhauhfgdsaffsafasus ",
    data: " safsaassssssssssssssssssssssssssssssssssssssfsg sa",
    categoria: "Tecnologia"
}]


module.exports = listaDePosts