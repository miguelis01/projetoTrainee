const express = require('express');
const controladores = require('../Controllers/controladores');

const routes = express();

//mostrando HOME
routes.get("/",controladores.home);

//Abrindo posts individuais  
routes.get("/post/:idConsultado",controladores.consultaPost);

module.exports = routes;

